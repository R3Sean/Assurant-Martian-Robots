﻿using System;
namespace mars.data
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
