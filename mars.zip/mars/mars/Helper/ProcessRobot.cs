﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
using mars.dto;
using mars.Models;

namespace mars
{
    public class ProcessRobot
    {
        private List<grid_position> scent = new List<grid_position>();
        private grid_position maxBound = new grid_position();

        public List<robot_control> SendRobots(MarsInput model)
        {
            List<robot_control> retList = new List<robot_control>();

            maxBound.x_coord = model.x_pos_max;
            maxBound.y_coord = model.y_pos_max;

            robot_control rob1 = new robot_control();
            grid_position rob1StartPos = new grid_position();
            rob1StartPos.x_coord = model.robot_1_x_pos;
            rob1StartPos.y_coord = model.robot_1_y_pos;
            rob1 = MoveRobot(rob1StartPos, model.robot_1_moves, model.robot_1_dir);

            retList.Add(rob1);

			robot_control rob2 = new robot_control();
			grid_position rob2StartPos = new grid_position();
			rob2StartPos.x_coord = model.robot_2_x_pos;
			rob2StartPos.y_coord = model.robot_2_y_pos;
			rob2 = MoveRobot(rob2StartPos, model.robot_2_moves, model.robot_2_dir);

            retList.Add(rob2);

			robot_control rob3 = new robot_control();
			grid_position rob3StartPos = new grid_position();
			rob3StartPos.x_coord = model.robot_3_x_pos;
			rob3StartPos.y_coord = model.robot_3_y_pos;
			rob3 = MoveRobot(rob3StartPos, model.robot_3_moves, model.robot_3_dir);

			retList.Add(rob3);

            return retList;
        }

        /// <summary>
        /// Moves the robot.
        /// </summary>
        /// <returns>The robot.</returns>
        /// <param name="startPos">Start position.</param>
        /// <param name="movesText">Moves text.</param>
        /// <param name="directionText">Direction text.</param>
        protected robot_control MoveRobot(grid_position startPos, string movesText, string directionText)
        {
            robot_control rob = new robot_control();
            rob.starting_position = startPos;
            rob.final_position = startPos;
            rob.direction = directionText.ToUpper();
            rob.moves = GetMoves(movesText.ToUpper());

            ChangePosition(rob);

            return rob;
        }

        protected void ChangePosition(robot_control obj)
        {

            foreach(var m in obj.moves)
            {
                switch(m)
                {
                    case "L":
                        obj.direction = TurnLeft(obj.direction);
                        break;
                    case "R":
                        obj.direction = TurnRight(obj.direction);
                        break;
                    case "F":
                        MovePosition(obj, maxBound);
                        break;

                }

            }
            
        }

        /// <summary>
        /// Turns the right.
        /// </summary>
        /// <returns>The right.</returns>
        /// <param name="existingDir">Existing dir.</param>
        protected string TurnRight(string existingDir)
        {
            string dir = existingDir;
            switch(existingDir.ToUpper())
            {
                case "N":
                    dir = "E";
                    break;
                case "E" :
                    dir = "S";
                    break;
                case "S":
                    dir = "W";
                    break;
                case "W":
                    dir = "N";
                    break;
                    
            }


            return dir;
        }

        /// <summary>
        /// Turns the left.
        /// </summary>
        /// <returns>The left.</returns>
        /// <param name="existingDir">Existing dir.</param>
        protected string TurnLeft(string existingDir)
        {
            
            string dir = existingDir;
			switch (existingDir.ToUpper())
			{
				case "N":
					dir = "W";
					break;
				case "E":
					dir = "N";
					break;
				case "S":
					dir = "E";
					break;
				case "W":
					dir = "S";
					break;

			}
            return dir;
        }

        /// <summary>
        /// Moves the position.
        /// </summary>
        /// <param name="obj">Object.</param>
        /// <param name="maxBound">Max bound.</param>
        protected void MovePosition(robot_control obj, grid_position maxBound)
        {
            grid_position newPos = new grid_position();
            switch(obj.direction)
            {
                case "N":
                    newPos.x_coord = obj.final_position.x_coord;
                    newPos.y_coord = obj.final_position.y_coord + 1;
                    break;
                case "S":
                    newPos.x_coord = obj.final_position.x_coord;
                    newPos.y_coord = obj.final_position.y_coord - 1;
                    break;
                case "E":
                    newPos.y_coord = obj.final_position.y_coord;
                    newPos.x_coord = obj.final_position.x_coord + 1;
                    break;
                case "W" :
                    newPos.y_coord = obj.final_position.y_coord;
                    newPos.x_coord = obj.final_position.x_coord - 1;
					break;

            }



            //update final position
            if (scent.Where(o => o.x_coord == newPos.x_coord && o.y_coord == newPos.y_coord).Count() == 0)
            {
                //add to sent list if object goes off grid
                if (newPos.x_coord > maxBound.x_coord || newPos.x_coord < 0 || newPos.y_coord > maxBound.y_coord || newPos.y_coord < 0)
                {
                    scent.Add(newPos);
                    obj.is_lost = true;
                }
                else //update to new position
                {
                    obj.final_position.x_coord = newPos.x_coord;
                    obj.final_position.y_coord = newPos.y_coord;

                }
            }

			


        }

        /// <summary>
        /// Gets the moves.
        /// </summary>
        /// <returns>The moves.  As list of strings</returns>
        /// <param name="moveText">Move text.</param>
        protected List<string> GetMoves(string moveText)
        {
			List<string> retList = new List<string>();

            foreach (var part in Regex.Matches(moveText.ToUpper(),".{1}").Cast<Match>())
			{
                switch(part.Value)
                {
                    case "R":
					case "L":
					case "F":
                        retList.Add(part.Value);
                        break;
                }

			}
            return retList;
        }



    }
}
