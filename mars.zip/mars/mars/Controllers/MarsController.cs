﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Text.RegularExpressions;
using mars.Models;
using mars.dto;

namespace mars.Controllers
{
    public class MarsController : Controller
    {
        public ActionResult Index()
        {
            MarsInput model = new MarsInput();
            return View (model);
        }

        [HttpPost]
        public ActionResult Index(MarsInput model)
        {
            List<string> moves = new List<string>();
            //string s = model.robot_1_moves;
            //foreach(var part in Regex.Matches(s, ".{1}").Cast<Match>())
            //{
            //    moves.Add(part.Value);
            //}
            ProcessRobot proc = new ProcessRobot();

            List<robot_control> robots = proc.SendRobots(model);

            //robot 1
            model.robot_1_pos = robots[0].final_position.x_coord.ToString() + " " + robots[0].final_position.y_coord.ToString() + " " + robots[0].direction;
            if (robots[0].is_lost)
                model.robot_1_pos = model.robot_1_pos + " LOST";

            //robot 2
			model.robot_2_pos = robots[1].final_position.x_coord.ToString() + " " + robots[1].final_position.y_coord.ToString() + " " + robots[1].direction;
			if (robots[1].is_lost)
				model.robot_2_pos = model.robot_2_pos + " LOST";

            //robot 3
			model.robot_3_pos = robots[2].final_position.x_coord.ToString() + " " + robots[2].final_position.y_coord.ToString() + " " + robots[2].direction;
			if (robots[2].is_lost)
				model.robot_3_pos = model.robot_3_pos + " LOST";

            return View(model);
        }

        public ActionResult Edit()
        {
            return View();
        }
    }
}
