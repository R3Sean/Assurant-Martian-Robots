﻿using System;
namespace mars
{
    public class command_model
    {
        public command_model()
        {
        }
    }
}
