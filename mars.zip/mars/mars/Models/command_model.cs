﻿using System;
using mars.dto;
using System.Collections;
using System.Collections.Generic;

namespace mars.Models
{
    public class command_model
    {
        public grid_position max_position;
        public List<robot_control> three_controls; 



        public command_model()
        {
            max_position = new grid_position();
            three_controls = new List<robot_control>();
        }
    }
}
