﻿using System;
namespace mars.Models
{
    public class MarsInput
    {
        public int x_pos_max { get; set; }
        public int y_pos_max { get; set; }

        public int robot_1_x_pos { get; set; }
        public int robot_1_y_pos { get; set; }
        public string robot_1_dir { get; set; }
        public string robot_1_moves { get; set; }

        public int robot_2_x_pos { get; set; }
        public int robot_2_y_pos { get; set; }
        public string robot_2_dir { get; set; }
        public string robot_2_moves { get; set; }

        public int robot_3_x_pos { get; set; }
        public int robot_3_y_pos { get; set; }
        public string robot_3_dir { get; set; }
        public string robot_3_moves { get; set; }

        public string robot_1_pos { get; set; }
        public string robot_2_pos {get; set;}
        public string robot_3_pos { get; set; }


        public MarsInput()
        {
        }
    }
}
