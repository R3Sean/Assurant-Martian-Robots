﻿using System;
namespace mars.dto
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
