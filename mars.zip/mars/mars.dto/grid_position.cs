﻿using System;
namespace mars.dto
{
    public class grid_position
    {
        public int x_coord { get; set; }
        public int y_coord { get; set; }

        public grid_position()
        {
        }
    }
}
