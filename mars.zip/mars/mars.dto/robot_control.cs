﻿using System;
using System.Collections;
using System.Collections.Generic;
namespace mars.dto
{
    public class robot_control
    {
        public grid_position starting_position { get; set; }
        public grid_position final_position { get; set; }
        public string direction { get; set; }
        public List<string> moves { get; set; }
        public bool is_lost { get; set; }

        public robot_control()
        {
            starting_position = new grid_position();
            final_position = new grid_position();
            moves = new List<string>();
            is_lost = false;
        }
    }
}
